# SGS E-Customs Map — Local Preview

Self-contained local development package with **external** CSS, JavaScript, and SVG files (nothing inlined).

## Contents

```
.
├── index.html          # Entry page
├── css/                # Stylesheets
├── js/
│   ├── loader.js       # Loads assets/svg/map.svg
│   └── map.js          # Map interaction logic
├── assets/
│   └── svg/
│       └── map.svg     # Europe map geometry
└── README.md
```

## Quick start

You must use a local HTTP server (browsers block `fetch()` for local files opened via `file://`).

### Option A — npx serve

```bash
npx serve .
```

Open http://localhost:3000

### Option B — Python

```bash
python3 -m http.server 8080
```

Open http://localhost:8080

### Option C — Node preview script (from repo root)

```bash
npm run preview
```

## Editing

| Change | File |
|--------|------|
| Layout / nav / intro | Edit `index.html` shell section |
| Styles | `css/*.css` |
| Map interaction | `js/map.js` |
| SVG geometry | `assets/svg/map.svg` |
| Country data | `index.html` (info-text blocks) |

After editing source files in the main repo, rebuild the package:

```bash
npm run package:local
```
