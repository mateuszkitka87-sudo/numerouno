/**
 * Loads external SVG before map.js initialises.
 * Requires a local HTTP server (fetch does not work on file://).
 */
window.ecMapReady = (async function loadMapSvg() {
  const mount = document.querySelector('.ec-map__svg-mount');
  if (!mount) {
    throw new Error('Missing .ec-map__svg-mount element');
  }

  const src = mount.getAttribute('data-svg');
  const response = await fetch(src);
  if (!response.ok) {
    throw new Error('Failed to load SVG: ' + src);
  }

  const svg = (await response.text()).trim();
  mount.insertAdjacentHTML('afterend', svg);
  mount.remove();
})();
