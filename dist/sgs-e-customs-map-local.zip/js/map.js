/**
 * Map interaction — waits for external SVG via js/loader.js
 */
window.ecMapReady.then(function () {
  jQuery(function ($) {
    var popupClass = '.info-text';
    	var $mapRoot = $('#interactive-map');
    	var desktopBreakpoint = 1000;
    	var popupPadding = 12;
    	var selectedCountry = null;
    	var countryMeta = {};
    	var animMs = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 280;
    
    	function isDesktopLayout() {
    		return $(window).width() >= desktopBreakpoint;
    	}
    
    	function isPointerHoverEvent(e) {
    		var pointerType = e.originalEvent && e.originalEvent.pointerType;
    		return !pointerType || pointerType === 'mouse';
    	}
    
    	function ensureCta($popup, countryUrl) {
    		if (!countryUrl || $popup.find('.button-map').length) return;
    		$popup.append(
    			'<a href="' + countryUrl + '" target="_blank" rel="noopener noreferrer" class="button-map">' +
    			'Read more <span class="button-map__chevron" aria-hidden="true">›</span></a>'
    		);
    	}
    
    	function showPopup($popup) {
    		$popup.css('display', 'block');
    		$popup.removeClass('is-visible');
    		$popup.attr('aria-hidden', 'false');
    		void $popup[0].offsetHeight;
    		$popup.addClass('is-visible');
    	}
    
    	function hidePopup($popup) {
    		if (!$popup.length || $popup.css('display') === 'none') return;
    		$popup.removeClass('is-visible');
    		$popup.attr('aria-hidden', 'true');
    		if (!animMs) {
    			$popup.css('display', 'none');
    			return;
    		}
    		setTimeout(function () {
    			if (!$popup.hasClass('is-visible')) {
    				$popup.css('display', 'none');
    			}
    		}, animMs);
    	}
    
    	function positionPopup($popup, $countryGroup) {
    		if (!isDesktopLayout()) {
    			$popup.removeClass('is-positioned');
    			return;
    		}
    
    		var mapEl = $mapRoot[0];
    		var countryEl = $countryGroup[0];
    		if (!mapEl || !countryEl) return;
    
    		var mapRect = mapEl.getBoundingClientRect();
    		var countryRect = countryEl.getBoundingClientRect();
    		var popupEl = $popup[0];
    		var wasVisible = $popup.hasClass('is-visible');
    
    		$popup.addClass('is-measuring').css('display', 'block');
    		var popupRect = popupEl.getBoundingClientRect();
    		if (!wasVisible) {
    			$popup.removeClass('is-measuring').css('display', 'none');
    		} else {
    			$popup.removeClass('is-measuring');
    		}
    
    		var left = countryRect.right - mapRect.left + popupPadding;
    		var top = countryRect.top - mapRect.top + (countryRect.height / 2) - (popupRect.height / 2);
    
    		if (left + popupRect.width > mapRect.width - popupPadding) {
    			left = countryRect.left - mapRect.left - popupRect.width - popupPadding;
    		}
    
    		top = Math.max(popupPadding, Math.min(top, mapRect.height - popupRect.height - popupPadding));
    
    		if (left < popupPadding) {
    			left = countryRect.left - mapRect.left + (countryRect.width / 2) - (popupRect.width / 2);
    			left = Math.max(popupPadding, Math.min(left, mapRect.width - popupRect.width - popupPadding));
    			top = countryRect.bottom - mapRect.top + popupPadding;
    			if (top + popupRect.height > mapRect.height - popupPadding) {
    				top = countryRect.top - mapRect.top - popupRect.height - popupPadding;
    			}
    			top = Math.max(popupPadding, Math.min(top, mapRect.height - popupRect.height - popupPadding));
    		}
    
    		popupEl.style.setProperty('--popup-top', top + 'px');
    		popupEl.style.setProperty('--popup-left', left + 'px');
    		$popup.addClass('is-positioned');
    	}
    
    	function applyHoverFill($group, type) {
    		if (type == 'transit') {
    			$group.find('path').css({ fill: '#ff8f1f' });
    		} else if (type == 'brokerage') {
    			$group.find('path').css({ fill: 'url(#brokeragestripeshover)' });
    		} else if (type == 'export') {
    			$group.find('path').css({ fill: 'url(#exportstripeshover)' });
    		} else {
    			$group.find('path').css({ fill: '#ff8f1f' });
    		}
    	}
    
    	function applyDefaultFill($group, type) {
    		if (type == 'transit') {
    			$group.find('path').css({ fill: '#ff6600' });
    		} else if (type == 'brokerage') {
    			$group.find('path').css({ fill: 'url(#brokeragestripes)' });
    		} else if (type == 'export') {
    			$group.find('path').css({ fill: 'url(#exportstripes)' });
    		} else {
    			$group.find('path').css({ fill: '#ff6600' });
    		}
    	}
    
    	function deselectCountry() {
    		if (!selectedCountry) return;
    		var name = selectedCountry;
    		var type = countryMeta[name];
    		var $popup = $(popupClass + "[data-name='" + name + "']");
    		var $group = $mapRoot.find('svg #' + name);
    		$popup.removeClass('is-selected');
    		hidePopup($popup);
    		$group.removeAttr('data-selected').attr('aria-expanded', 'false');
    		applyDefaultFill($group, type);
    		selectedCountry = null;
    	}
    
    	function selectCountry(countryName, $popup, $group) {
    		if (selectedCountry && selectedCountry !== countryName) {
    			deselectCountry();
    		}
    		selectedCountry = countryName;
    		$popup.addClass('is-selected');
    		$group.attr({ 'data-selected': 'true', 'aria-expanded': 'true' });
    		positionPopup($popup, $group);
    		showPopup($popup);
    		applyHoverFill($group, countryMeta[countryName]);
    	}
    
    	$(document).on('keydown', function (e) {
    		if (e.key === 'Escape') {
    			deselectCountry();
    		}
    	});
    
    	$mapRoot.on('click', function (e) {
    		if (!$(e.target).closest('g[id]').length && !$(e.target).closest('.info-text').length) {
    			deselectCountry();
    		}
    	});
    
    	$mapRoot.on('click', '.ec-detail-card__close', function (e) {
    		e.preventDefault();
    		e.stopPropagation();
    		deselectCountry();
    	});
    
    	$(window).on('resize orientationchange', function () {
    		if (!selectedCountry) return;
    		var $popup = $(popupClass + "[data-name='" + selectedCountry + "']");
    		var $group = $mapRoot.find('svg #' + selectedCountry);
    		positionPopup($popup, $group);
    	});
    
    	$('.info-text').each(function () {
    		// Get data attributes
    		var countryName = $(this).data('name');
    		var countryUrl = $(this).data('url');
    		var countryType = $(this).data('type');
    		countryMeta[countryName] = countryType;
    
    		// Set data names
    		var mapName = "#" + countryName;
    		var popupName = "[data-name='" + countryName + "']";
    		var $popup = $(popupClass + popupName);
    		ensureCta($popup, countryUrl);
    		$popup.attr({ role: 'region', 'aria-hidden': 'true' });
    
    		// Add class to svg country path with
    		$(this).parent().find('svg ' + mapName + ' path').addClass(countryType);
    
    		// Add class if url exists
    		if (countryUrl) {
    			$(this).parent().find('svg ' + mapName + ' path').addClass('has_url');
    		}
    
    		// If data type is not inactive
    		if (countryType !== 'inactive') {
    
    			// Find every svg with the country name
    			var svg = $(this).parent().find('svg ' + mapName);
    			var countryLabel = $popup.find('h3').first().text() || countryName;
    
    			svg.attr({
    				tabindex: 0,
    				role: 'button',
    				'aria-label': countryLabel,
    				'aria-expanded': 'false',
    				'aria-controls': 'popup-' + countryName
    			});
    			$popup.attr('id', 'popup-' + countryName);
    
    			svg.on('keydown', function (e) {
    				if (e.key === 'Enter' || e.key === ' ') {
    					e.preventDefault();
    					$(this).trigger('click');
    				}
    			});
    
    			svg.on('mouseenter', function (e) {
    				if (!isPointerHoverEvent(e)) return;
    				var $popup = $(popupClass + popupName);
    				positionPopup($popup, svg);
    				showPopup($popup);
    				applyHoverFill($(this), countryType);
    			});
    
    			svg.on('mouseleave', function (e) {
    				if (!isPointerHoverEvent(e)) return;
    				if (selectedCountry === countryName) return;
    				hidePopup($(popupClass + popupName));
    				applyDefaultFill($(this), countryType);
    			});
    
    			svg.on('click', function (e) {
    				e.preventDefault();
    				e.stopPropagation();
    				var $popup = $(popupClass + popupName);
    				if (selectedCountry === countryName) {
    					deselectCountry();
    				} else {
    					selectCountry(countryName, $popup, svg);
    				}
    				if (!countryUrl) {
    					console.log('No url given.');
    				}
    			});
    
    		}
    	});

  });
});
